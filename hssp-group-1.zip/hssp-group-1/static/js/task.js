/* task.js
 *
 * This file holds the main experiment code.
 *
 * Requires:
 *   config.js
 *   psiturk.js
 *   utils.js
 */

// Create and initialize the experiment configuration object
var $c = new Config(condition, counterbalance);

// Initalize psiturk object
var psiTurk = new PsiTurk(uniqueId, adServerLoc);

//Global variable container to randomize variables presented
var globContain = {};
var splitsChosen = [0, 1, 2, 3, 4, 5, 6, 7, 8];
var idx = 0;
//randomizes choices presented
var currentIndex = splitsChosen.length, temporaryValue, randomIndex;
// While there remain elements to shuffle...
while (0 !== currentIndex) {

  // Pick a remaining element...
  randomIndex = Math.floor(Math.random() * currentIndex);
  currentIndex -= 1;

  // And swap it with the current element.
  temporaryValue = splitsChosen[currentIndex];
  splitsChosen[currentIndex] = splitsChosen[randomIndex];
  splitsChosen[randomIndex] = temporaryValue;
}

// Preload the HTML template pages that we need for the experiment
psiTurk.preloadPages($c.pages);

// Objects to keep track of the current phase and state
var CURRENTVIEW;
var STATE;


/*************************
 * INSTRUCTIONS
 *************************/

var Instructions = function() {
//    var view = that.trialinfo ;
  debug("show slide #instructions-training-1");

  $(".slide").hide();
  var slide = $("#instructions-training-1");
  slide.fadeIn($c.fade);

    view = {
        "name1"  : "Jesse",
        "name2"  : "Alex",
    };

    $(".instruct_text").html(Mustache.render(Mustache.render($c.story, view), view));

    // get rid of this to show
    // CURRENTVIEW = new TestPhase();
    // CURRENTVIEW = new Demographics();

    slide.find('.next').click(function () {
        CURRENTVIEW = new TestPhase();
    });


};


 var Instructions_Test = function() {
    this.show = function() {
        // Load the next page of instructions
        debug("show slide #instructions-test-1");
        $(".slide").hide();
        var slide = $("#instructions-test-1");
        slide.fadeIn($c.fade);

        // this.finish();
        // Bind a handler to the "next" button. We have to wrap it in
        // an anonymous function to preserve the scope.
        var that = this;
        slide.find('.next').unbind('click');
        slide.find('.next').click(function () {
            that.check_quiz();
        });

    };

    this.check_quiz = function() {
        debug("grading quiz") ;
        var qs = {
            'knows1': 'No',
            // 'knows2': 'Yes'
            // 'knows3': 'No'
        } ;

        var allcorrect = 1 ;
        for (var key in qs) {
            var selector = 'input[name='+key+']:checked' ;
            if ($(selector).val() != qs[key]) {
                allcorrect = 0;
                break ;
            }
        }

        if (allcorrect) {
            // Record that the user has finished the instructions and
            // moved on to the experiment. This changes their status
            // code in the database.
            debug("Done with instructions") ;
            psiTurk.recordUnstructuredData('fail_instructions', STATE.fail_instructions);
            psiTurk.finishInstructions();

            // Reset the state object for the test phase
            CURRENTVIEW = new TestPhase();
        } else {
            $('#quiz').find(':checked').each(function() {
                $(this).removeAttr('checked');
            });
            // Log the failure
            STATE.fail_instructions++ ;
            CURRENTVIEW = new Instructions() ;
        }
    };

    // Display the first page of instructions
//    this.show();
};

/*****************
 *  TRIALS       *
 *****************/

var TestPhase = function() {

    // kill the instructions so they don't interfere with the radio button counts
    $("#instructions-test-1").html('');


    // Initialize a new trial. This is called either at the beginning
    // of a new trial, or if the page is reloaded between trials.
    this.init_trial = function () {
        debug("Initializing trial " + STATE.index);

        // If there are no more trials left, then we are at the end of
        // this phase
        if (STATE.index >= $c.trials.length) {
            CURRENTVIEW = new Demographics() ;
            return false;
        }

        // Load the new trialinfo
        this.trialinfo = $c.trials[STATE.index];

        // Update progress bar
        update_progress(STATE.index, $c.trials.length);

        return true;
    };

    this.display_stim = function (that) {
        var i,j ;
        if (that.init_trial()) {
            debug("Show STIMULUS");

            // Replace the name with the piece from the template
            var view = that.trialinfo ;
            $("#story").html(Mustache.render(Mustache.render($c.story, view), view));

            // Create the HTML for the question and slider.
            var html = "" ;
            var lshtml = "" ;
            var nq = 0;
            globContain.colNum = splitsChosen[idx];
            idx++;
            cnum = globContain.colNum;
            var listLength = $c.questions[cnum].length;

            //truncates and sorts randomized list to present options numerically
            //splitsChosen = splitsChosen.slice(0,split);
            //splitsChosen = splitsChosen.sort(function(a,b){return a-b});

            for (i=0; i<listLength; i++) {
//                var sp = splitsChosen[i];
                var q = Mustache.render(Mustache.render($c.questions[cnum][i].q, view),view);
                var n = Mustache.render(Mustache.render($c.questions[cnum][i].n, view),view);
                var words = Mustache.render(Mustache.render($c.questions[cnum][i].w, view), view);
                var ways = Mustache.render(Mustache.render($c.questions[cnum][i].p, view), view);
                html += '<p class="question">' + q
                +' <span class="q-'+i+'"></span></p>' ;
                var br = Mustache.render("<br />", view);
                lshtml += n + br
            }

		var sidebarhtml = '';
		var s = Mustache.render("The Host has given you $1000! You can keep all of it and risk serious damage to your social reputation, or return some of the money to avoid damage. To avoid slander, use the slider to indicate how much (on a scale of $0 to $1000) you would like to return.",view);
    var nums = listLength.toString(10);
		sidebarhtml = sidebarhtml + s;

            $('#choices').html(html) ;
            $('#sidebar').html(sidebarhtml) ;

            // Bulid the radios/sliders for each question
            for (i=0; i<listLength; i++) {
                //sp = splitsChosen[i];
                if ($c.counterbalance==0) {

                    $('.q-'+i).html('<br/><div class="slider s-'+ i +'"></div><div class="l-'+ i +' sliderlabels"></div>') ;
                    // make the labels

                    $('.l-'+i).append("<label style='width: 33.3%; height: 20px'>"+ Mustache.render($c.questions[cnum][i].l[0], view) +"</label>") ;
                    $('.l-'+i).append("<label style='width: 33.3%; height: 20px'>"+ Mustache.render($c.questions[cnum][i].l[1], view) +"</label>") ;
                    $('.l-'+i).append("<label style='width: 33.3%; height: 20px'>"+ Mustache.render($c.questions[cnum][i].l[2], view) +"</label>") ;

                }
                else {

                    var qhtml = '<br />' ;

                    for (j=0; j<$c.questions[cnum][j].l.length; j++) {
                        var ltext = Mustache.render($c.questions[cnum][i].l[j], view) ;
                        qhtml += Mustache.render('&nbsp;&nbsp;<input type="radio" id="{{id}}" name="{{name}}" /><label  style="font-size:16px" for="{{id}}">{{label}}</label><br />', {'id': 'q-'+i+'-'+j, 'name': 'q-'+i, 'label':ltext}) ;
                    } ;
                    $('.q-'+i).html(qhtml) ;
                    // make sure all radio buttons have been checked
                    $('.q-'+i).buttonset().click(function () {
                        if ($(':radio:checked').length + $('.slider').find('.ui-slider-handle').is(":visible") == nq) {
                            $('#trial_next').prop('disabled', false) ;
                        }
                    }) ;

                }
            }

            $('.slider').slider().on("slidestart", function( event, ui ) {
                // Show the handle
                $(this).find('.ui-slider-handle').show() ;

                // Sum is the number of sliders that have been clicked
                var sum = 0 ;
                for (var j=0; j<listLength; j++) {
                    if ($('.q-'+j).find('.ui-slider-handle').is(":visible")) {
                        sum++ ;
                    }
                }
                // If the number of sliders clicked is equal to the number of sliders
                // the user can continue.
                if (sum == listLength) {
                    $('#trial_next').prop('disabled', false).css('opacity',1) ;
                }
            });

            $('.ui-slider-handle').hide() ;

            // Disable button which will be enabled once the sliders are clicked
            $('#trial_next').prop('disabled', true).css('opacity',0.5);

            debug(that.trialinfo);
        }
    };

    // Record a response (this could be either just clicking "start",
    // or actually a choice to the prompt(s))
    this.record_response = function() {
        cnum = globContain.colNum;
        var response = {} ;

        if ($c.questions[cnum].length>1) {
            for (var i=0; i<$c.questions[cnum].length; i++) {
                response[$c.questions[cnum][i].q] = $('.s-'+i).slider('value') ;
            }
            psiTurk.recordUnstructuredData(STATE.index, response) ;
        } else {
            radioid = $('input[name=q-'+ 0 +']:radio:checked').attr("id");
            response[$c.questions[cnum][0].q] = $("label[for='"+radioid+"']").text() ;
            psiTurk.recordUnstructuredData(STATE.index, response) ;
        }

        // Increment index to goto the next trial
	 $("#sidebar").html('') ;
        STATE.index++ ;

        // Update the page with the current phase/trial
        // This causes the fade between page views
        $(".slide").hide();
        $("#trial").fadeIn($c.fade);
        this.display_stim(this);
    };

    // Load the trial html page
    $(".slide").hide();

    // Show the slide
    var that = this;
    $("#trial").fadeIn($c.fade);
    $('#trial_next.next').unbind('click');
    $('#trial_next.next').click(function () {
        that.record_response();
    });


    // Initialize the current trial
    if (this.init_trial()) {
        // Start the test
        this.display_stim(this) ;
    };
};

/*****************
 *  DEMOGRAPHICS*
 *****************/

var Demographics = function(){

    // Complete the set of trials in the test phase

    this.finish = function() {
        debug("Finish test phase");

        // If we're at the end of the experiment, submit the data to
        // mechanical turk, otherwise go on to the next experiment
        // phase and show the relevant instructions

        // Show a page saying that the HIT is resubmitting, and
        // show the error page again if it times out or error
        var resubmit = function() {
            $(".slide").hide();
            $("#resubmit_slide").fadeIn($c.fade);

            var reprompt = setTimeout(prompt_resubmit, 10000);
            psiTurk.saveData({
                success: function() {
                    clearInterval(reprompt);
                    finish();
                },
                error: prompt_resubmit
            });
        };

        // Prompt them to resubmit the HIT, because it failed the first time
        var prompt_resubmit = function() {
            $("#resubmit_slide").click(resubmit);
            $(".slide").hide();
            $("#submit_error_slide").fadeIn($c.fade);
        };

        // Render a page saying it's submitting
        psiTurk.showPage("submit.html") ;
        psiTurk.saveData({
            success: psiTurk.completeHIT,
            error: prompt_resubmit
        });
    };

    $(".slide").hide();
    var slide = $("#demographics");
    slide.fadeIn($c.fade);

    var that = this;
    $('.next').click(function () {
        // save the gender age comments here using recorddata
        psiTurk.recordUnstructuredData('gender',$('input[name = sex]:checked').val());
        psiTurk.recordUnstructuredData('age',$('input[name = age]').val());
        psiTurk.recordUnstructuredData('pol',$('input[name = pol]:checked').val());
        psiTurk.recordUnstructuredData('feedback',$('textarea[name = feedback]').val());
        that.finish();
    });
};



// --------------------------------------------------------------------
// --------------------------------------------------------------------

/*******************
 * Run Task
 ******************/

$(document).ready(function() {
    // Load the HTML for the trials
    psiTurk.showPage("trial.html");

    // Start the experiment
    STATE = new State();
    var response = [] ;
    for (var i=0; i<$c.trials.length; i++) {
        response.push($c.trials[i]);
    }
    psiTurk.recordUnstructuredData('trials', response) ;

    // Begin the experiment phase
    CURRENTVIEW = new Instructions();

});
