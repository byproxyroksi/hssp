/* config.js
 *
 */

var Config = function (condition, counterbalance) {

    // These are the condition and counterbalancing ids

    // condition is which one is first
    this.condition = condition;
    // counterbalance is whether or not to show the two at the same time
    if (counterbalance>=0) {
        this.counterbalance = 0 ;
        counterbalance = 0 ;
    } else {
        this.counterbalance = 0 ;
        counterbalance = 0 ;
    }
    // testing
    // this.counterbalance = counterbalance = 0 ;

    // Whether debug information should be printed out
    this.debug = true;
    // The amount of time to fade HTML elements in/out
    this.fade = 200;
    // List of trial information object for each experiment phase
    this.trials = new Object();

    // Lists of pages and examples for each instruction page.  We know
    // the list of pages we want to display a priori.
    this.instructions = {
        pages: ["instructions-training-1"]
    };


    // The list of all the HTML pages that need to be loaded
    this.pages = [
        "trial.html",
        "submit.html"
    ];

    // Parse the JSON object that we've requested and load it into the
    // configuration
    this.parse_config = function () {
        // This is information that is shared across stimuli

        var data = {
            "story": [
                "Instructions"
            ],
            "choices" : [""],
            "fair" : ["fair"],
            "unfair" : ["unfair"],
            "reasonable" : ["reasonable"],
            "unreasonable" : ["unreasonable"],
            "unpraiseworthy": ["unpraiseworthy"],
            "praiseworthy" : ["praiseworthy"],
            "blameworthy" : ["blameworthy"],
            "blameless" : ["blameless"],
            "names": ["Jesse", "Luke", "Jack", "Max", "Eric", "Bryce", "Kyle", "Sean", "Jake", "Grant", "Mark", "Seth", "Paul", "Frank", "Scott", "Trent", "Chris", "Bruce", "Sam", "Joe", "Brett", "Chad", "Carl", "Neil", "Will", "Ray", "Ben", "Hank", "Steve", "Brent", "Craig", "Jacob", "Dan", "David", "Ryan", "Victor", "Oscar", "Ian", "Ned", "Lucas", "Tyler", "Jason", "Justin", "Ivan", "Pat", "Bob"]
        } ;

        var qs = [
          [
            {"q": "How trustworthy is Janet?", "l": ["Very", "Neutral", "Not at all"], "n": "• Janet is married with two kids", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Brad?", "l": ["Very", "Neutral", "Not at all"], "n": "• Brad is a graduate student", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Eddie?", "l": ["Very", "Neutral", "Not at all"], "n": "• Eddie 40 year old divorcée", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Betty?", "l": ["Very", "Neutral", "Not at all"], "n": "• Betty is 16 year old", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"}
          ],
          [
            {"q": "How trustworthy is Janet?", "l": ["Very", "Neutral", "Not at all"], "n": "• Janet is a philanthropist", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Brad?", "l": ["Very", "Neutral", "Not at all"], "n": "• Brad gives spare money to needy", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Eddie?", "l": ["Very", "Neutral", "Not at all"], "n": "• Eddie volunteers at animal shelters", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Betty?", "l": ["Very", "Neutral", "Not at all"], "n": "• Betty tutors classmates", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"}
          ],
          [
            {"q": "How trustworthy is Janet?", "l": ["Very", "Neutral", "Not at all"], "n": "• Janet is married to a billionaire", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Brad?", "l": ["Very", "Neutral", "Not at all"], "n": "• Brad has lots of student loans", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Eddie?", "l": ["Very", "Neutral", "Not at all"], "n": "• Eddie is CEO of a failing company", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Betty?", "l": ["Very", "Neutral", "Not at all"], "n": "• Betty is a part time grocery store employee", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"}
          ],
          [
            {"q": "How trustworthy is Janet?", "l": ["Very", "Neutral", "Not at all"], "n": "• Janet is in therapy for schizophrenia", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Brad?", "l": ["Very", "Neutral", "Not at all"], "n": "• Brad was caught breaking and entering", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Eddie?", "l": ["Very", "Neutral", "Not at all"], "n": "• Eddie lies on taxes", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"},
            {"q": "How trustworthy is Betty?", "l": ["Very", "Neutral", "Not at all"], "n": "• Betty steals regularly", "w": "11 ways to split the money.", "p": "{{name1}} has the following options:"}
          ]
        ];

        var wordSelect = Math.random() ;
        if (wordSelect <= 0.25) {
          var conds = ["Fair"];
          this.wordSelect = 0;
        } else if (wordSelect <= 0.5) {
          var conds =  ["Reasonable"];
          this.wordSelect = 1;
        } else if (wordSelect <= 0.75) {
          var conds = ["Praise"];
          this.wordSelect = 2;
        } else {
          var conds = ["Blame"];
          this.wordSelect = 3;
        };

        this.story = data['story'][counterbalance] ;
        this.questions = qs ;
        this.trials = [];

        var selected_conds;

        // Create all stimuli
        for (var i=0; i<4; i++) {

            if (counterbalance==0) {
                selected_conds = _.sample(_.range(conds.length), 1);
            } else {
                //selected_conds = [0] ;
                selected_conds = _.sample(_.range(conds.length), 1);
            };

            for (var j=0; j<selected_conds.length; j++) {

                // Create Names
                var nameIndex1 = Math.floor(Math.random() * data["names"].length);
                var name1 = data["names"][nameIndex1] ;
                data["names"].splice(nameIndex1, 1);

                var nameIndex2 = Math.floor(Math.random() * data["names"].length);
                var name2 = data["names"][nameIndex2] ;
                data["names"].splice(nameIndex2, 1);

                if (counterbalance==0) {
                    var nameIndex3 = Math.floor(Math.random() * data["names"].length);
                    var name3 = data["names"][nameIndex3] ;
                    data["names"].splice(nameIndex3, 1);
                };

                var word_choice1 = "";
                var word_choice2 = "";

                if (conds[selected_conds[j]] == "Fair"){
                  word_choice1 = data["fair"];
                  word_choice2 = data["unfair"];
                } else if (conds[selected_conds[j]] == "Reasonable"){
                  word_choice1 = data["reasonable"];
                  word_choice2 = data["unreasonable"];
                }
                else if (conds[selected_conds[j]] == "Praise"){
                  word_choice1 = data["praiseworthy"];
                  word_choice2 = data["unpraiseworthy"];
                } else {
                  word_choice1 = data["blameless"];
                  word_choice2 = data["blameworthy"];
                };

                this.trials.push({
                    "name1"  : name1,
                    "name2"  : name2,
                    "name3"  : name3,
                    "word_choice1" : word_choice1,
                    "word_choice2" : word_choice2,
                    "cond": conds[selected_conds[j]],
                    "fair": data['fair'],
                    "unfair": data['unfair'],
                    "praiseworthy": data['praiseworthy'],
                    "unpraiseworthy": data['unpraiseworthy'],
                    "blameworthy": data['blameworthy'],
                    "blameless": data['blameless'],
                    "reasonable": data['reasonable'],
                    "unreasonable": data['unreasonable']
                })
            };
        };

        //this.trials = _.shuffle(this.trials) ;
        // console.log(this.trials);
    };

    // Request from the server configuration information for this run
    // of the experiment
    this.parse_config();
};
